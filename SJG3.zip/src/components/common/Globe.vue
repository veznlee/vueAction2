<template>

</template>

<script>
    let hostUrl = 'http://192.168.1.75'
    export default {
        hostUrl
    }
</script>

<style scoped>

</style>
