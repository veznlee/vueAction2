import request from '../utils/request'

//自定义信息

//显示菜单信息
export function findMenu(param) {
    return request({
        url: '/windowsInfo/findMenu',
        method: 'get',
        params: param
    })
}
//保存或修改节点信息
export function saveAndUpdateTaskNodeInfo(param) {
    return request({
        url: '/windowsInfo/saveAndUpdateTaskNodeInfo',
        method: 'post',
        params: param
    })
}

//批量保存节点
export function saveBatchTaskNodeInfo(param) {
    return request({
        url: '/windowsInfo/saveBatchTaskNodeInfo',
        method: 'post',
        params: param
    })
}

//删除节点信息
export function delTaskNodeInfo(param) {
    return request({
        url: '/windowsInfo/delTaskNodeInfo',
        method: 'get',
        params: param
    })
}

//主页设计(定义操作)
export function designHomePage(param) {
    return request({
        url: '/windowsInfo/designHomePage',
        method: 'post',
        params: param
    })
}

//办理页设计
export function designOrderdesignHomePage(param) {
    return request({
        url: '/windowsInfo/designOrderdesignHomePage',
        method: 'post',
        params: param
    })
}



